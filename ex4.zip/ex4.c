/******************
Name: Omri Halfon
ID: 324209402
Assignment: ex4
*******************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define constants
#define NUMBER_OF_ROWS_IN_PYRAMID 5 // Number of rows in the pyramid
#define SIZE 20 // General size for arrays
#define MAX_LETTERS 15 // Maximum number of letters per word

// Function declarations for tasks
void task1_robot_paths(); // Task 1: Calculate robot paths
void task2_human_pyramid(); // Task 2: Simulate human pyramid weights
void task3_parenthesis_validator(); // Task 3: Validate parentheses
void task4_queens_battle(); // Task 4: Solve the queens puzzle
void task5_crossword_generator(); // Task 5: Generate a crossword puzzle

// Helper function declarations

// Update weight in human pyramid
float update_weight(int row, int column, float weights[NUMBER_OF_ROWS_IN_PYRAMID][NUMBER_OF_ROWS_IN_PYRAMID]);
// Calculate number of paths for robot
int number_of_paths(int column, int row);
// Get valid parenthesis character
char getpernatesis(char c);
// Get matching closing parenthesis
char getopositesis(char c);
// Check if parentheses are valid
int validparenthesis(char open);
// Check if row is safe for a queen
int isRowQueen(char solve[SIZE][SIZE], int row, int col, int N);
// Check if column is safe for a queen
int isColQueen(char solve[SIZE][SIZE], int row, int col, int N);
// Check if diagonals are safe for a queen
int closeQueen(char solve[SIZE][SIZE], int row, int col, int N);
// Validate zones in queens puzzle
int zoneCheck(char solve[SIZE][SIZE], char board[SIZE][SIZE],
    char zone, int row, int col, int N);
// Perform all checks for queens
int checkAll(char solve[SIZE][SIZE], char board[SIZE][SIZE], int rowQ, int colQ, int N);
// Place all queens
int placeAllQueens(char solve[SIZE][SIZE], char board[SIZE][SIZE], int row, int col, int N);
// Count letters in a word
int count_letters(char words[SIZE][MAX_LETTERS], int specRow, int col);
// Place a word in the crossword grid
void place_word_by_position(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE],
    int specRow, int colWord, int rowGrid, int colGrid, int length,char direction, int gridSize);
// Clean a grid section
void clean_grid(char grid[SIZE][SIZE], int row, int col, int length, char direction);
// Check word crossing validity
int check_crossing(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int specRow, int wordCol,
    int wordRow, char direction, int length, int col, int row, int sizeGrid);
// Check all crossword constraints
int check_all(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int specRow, int wordCol, int wordRow,
    char direction, int length, int col, int row, int sizeGrid);
// Place all words in the crossword grid
int place_all_words(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int slots, int slot, char directions[],
    int place[][3], int wordIndex[], int wordToTry, int sizeGrid);

float update_weight(int row, int column, float weights[NUMBER_OF_ROWS_IN_PYRAMID][NUMBER_OF_ROWS_IN_PYRAMID]) {
    if (row == 0) { // Top row
        return weights[row][0];
    }
    if (column == 0) { // Left edge
        return weights[row][column] + (update_weight(row - 1, column, weights) / 2);
    }
    if (column == row) { // Right edge
        return weights[row][column] + (update_weight(row - 1, column - 1, weights) / 2);
    }
    // Middle elements
    return weights[row][column] + (update_weight(row - 1, column, weights) / 2) +
        (update_weight(row - 1, column - 1, weights) / 2);
}

int number_of_paths(int column, int row) {
    if (column == 0 && row == 0) { // Base case: reached home
        return 1;
    }
    if (column < 0 || row < 0) { // Out of bounds
        return 0;
    }
    // Recursive case: sum of paths from left and above
    return number_of_paths(column, row - 1) + number_of_paths(column - 1, row);
}

char getopositesis(char c) {
    // Return the matching closing parenthesis for a given opening parenthesis
    switch (c) {
        case '(': return ')';
        case '[': return ']';
        case '<': return '>';
        case '{': return '}';
        default: return 0;
    }
}

char getpernatesis(char c) {
    // Return the valid parenthesis character
    switch (c) {
        case '(': return c;
        case ')': return ')';
        case '[': return '[';
        case ']': return ']';
        case '<': return '<';
        case '>': return '>';
        case '{': return '{';
        case '}': return '}';
        case '\n': return '\n';
        default: return 0;
    }
}

int validparenthesis(char open) {
    char current;
    if (scanf("%c", &current) != 1 || current == '\n') { // End of input
        if (open != '\0') {
            return 1; // Unmatched opening parenthesis
        }
        return 0; // Valid
    }

    if (getpernatesis(current) == 0) { // Ignore invalid characters
        return validparenthesis(open);
    }
    if (current == '(' || current == '[' || current == '{' || current == '<') {
        if (validparenthesis(current) == 1) {
            return 1; // Invalid
        }
        return validparenthesis(open); // Continue checking
    }

    if (current == ')' || current == ']' || current == '}' || current == '>') {
        if (open == '\0' || getopositesis(open) != current) {
            scanf("%*s");
            return 1; // Invalid
        }
        return 0; // Valid
    }

    return 1; // Invalid
}

int isRowQueen(char solve[SIZE][SIZE], int row, int col, int N) {
    if (col >= N) // Checked all columns in the row
        return 1;
    if (solve[row][col] == 'X') // Queen found
        return 0;
    return isRowQueen(solve, row, col + 1, N); // Check next column
}

int isColQueen(char solve[SIZE][SIZE], int row, int col, int N) {
    if (row >= N) // Checked all rows in the column
        return 1;
    if (solve[row][col] == 'X') // Queen found
        return 0;
    return isColQueen(solve, row + 1, col, N); // Check next row
}

int closeQueen(char solve[SIZE][SIZE], int row, int col, int N) {
    // Check if queens are too close diagonally
    if (row < N - 1 && col < N - 1 && solve[row + 1][col + 1] == 'X')
        return 0;
    if (row > 0 && col < N - 1 && solve[row - 1][col + 1] == 'X')
        return 0;
    if (row < N - 1 && col > 0 && solve[row + 1][col - 1] == 'X')
        return 0;
    if (row > 0 && col > 0 && solve[row - 1][col - 1] == 'X')
        return 0;
    return 1; // Safe
}

int zoneCheck(char solve[SIZE][SIZE], char board[SIZE][SIZE], char zone, int row, int col, int N) {
    if (row >= N) // Checked all rows
        return 1;
    if (col >= N) // Checked all columns in the row
        return zoneCheck(solve, board, zone, row + 1, 0, N);
    if (board[row][col] == zone && solve[row][col] == 'X') // Queen violates zone
        return 0;
    return zoneCheck(solve, board, zone, row, col + 1, N); // Continue checking
}

int checkAll(char solve[SIZE][SIZE], char board[SIZE][SIZE], int rowQ, int colQ, int N) {
    // Check all constraints for placing a queen
    return isRowQueen(solve, rowQ, 0, N) &&
           isColQueen(solve, 0, colQ, N) &&
           closeQueen(solve, rowQ, colQ, N) &&
           zoneCheck(solve, board, board[rowQ][colQ], 0, 0, N);
}

int placeAllQueens(char solve[SIZE][SIZE], char board[SIZE][SIZE], int row, int col, int N) {
    if (row >= N) // All queens placed
        return 1;
    if (col >= N) // Out of bounds
        return 0;
    if (checkAll(solve, board, row, col, N)) { // Check if position is valid
        solve[row][col] = 'X'; // Place queen
        if (placeAllQueens(solve, board, row + 1, 0, N))
            return 1; // Successful placement
        solve[row][col] = '*'; // Backtrack
    }
    return placeAllQueens(solve, board, row, col + 1, N); // Try next column
}

int count_letters(char words[SIZE][MAX_LETTERS], int specRow, int col) {
    // Base case: reached the end of the word or exceeded max letters
    if (col >= MAX_LETTERS || words[specRow][col] == '\0') {
        return 0;
    }
    // Recursive case: count the current letter and move to the next
    return 1 + count_letters(words, specRow, col + 1);
}

int check_crossing(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int specRow, int wordCol,
    int wordRow, char direction, int length, int col, int row, int sizeGrid) {
    // Base case: all letters placed
    if (length <= 0) {
        return 1;
    }
    // Check if the position is out of grid bounds
    if (col < 0 || col >= sizeGrid || row < 0 || row >= sizeGrid) {
        return 0;
    }
    // Check if the grid cell is already occupied by a different character
    if (grid[row][col] != '#' && grid[row][col] != words[specRow][wordCol]) {
        return 0;
    }
    // Recursive case for horizontal placement
    if (direction == 'H') {
        return check_crossing(words, grid, specRow, wordCol + 1,wordRow, direction, length - 1, col + 1,row,sizeGrid);
    // Recursive case for vertical placement
    } else if (direction == 'V') {
        return check_crossing(words, grid, specRow, wordCol+1, wordRow+1, direction,length-1, col, row + 1,sizeGrid);
    }
    // Invalid direction
    return 0;
}

int check_all(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int specRow,
    int wordCol, int wordRow, char direction, int length, int col, int row, int sizeGrid) {
    // Ensure the word can be placed and the length matches the dictionary word
    return check_crossing(words, grid, specRow, wordCol, wordRow, direction, length, col, row, sizeGrid) &&
           (length == count_letters(words, specRow, 0));
}

void place_word_by_position(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int specRow,
    int colWord, int rowGrid, int colGrid, int length, char direction, int gridSize) {
    // Base case: all letters placed
    if (length <= 0) {
        return;
    }
    // Place the letter in the current grid position
    if (direction == 'H') {
        grid[rowGrid][colGrid] = words[specRow][colWord]; // Place horizontally
        place_word_by_position(words, grid, specRow, colWord + 1, rowGrid, colGrid + 1, length - 1,direction, gridSize);
    } else if (direction == 'V') {
        grid[rowGrid][colGrid] = words[specRow][colWord]; // Place vertically
        place_word_by_position(words, grid, specRow, colWord + 1, rowGrid + 1, colGrid, length - 1,direction, gridSize);
    }
}

void clean_grid(char grid[SIZE][SIZE], int row, int col, int length, char direction) {
    // Base case: cleaned all positions
    if (length <= 0) {
        return;
    }
    // Check bounds to avoid invalid grid access
    if (row < 0 || col < 0 || row >= SIZE || col >= SIZE) {
        return;
    }
    // Reset the current grid position
    grid[row][col] = '#';
    // Recursive case: clean horizontally or vertically
    if (direction == 'H') {
        clean_grid(grid, row, col + 1, length - 1, direction);
    } else if (direction == 'V') {
        clean_grid(grid, row + 1, col, length - 1, direction);
    }
}

int place_all_words(char words[SIZE][MAX_LETTERS], char grid[SIZE][SIZE], int slots, int slot,
    char directions[], int place[][3], int wordIndex[], int wordToTry, int sizeGrid) {
    // Base case: all slots filled
    if (slot >= slots) {
        return 1;
    }
    // Base case: no more words to try
    if (wordToTry >= SIZE) {
        return 0;
    }

    // Get current slot details
    char direction = directions[slot];
    int row = place[slot][0];
    int col = place[slot][1];
    int length = place[slot][2];

    // Skip already used words
    if (wordIndex[wordToTry]) {
        return place_all_words(words, grid, slots, slot, directions, place, wordIndex, wordToTry + 1, sizeGrid);
    }

    // Check if the current word can fit in the slot
    if (check_all(words, grid, wordToTry, 0, row, direction, length, col, row, sizeGrid)) {
        place_word_by_position(words, grid, wordToTry,0,row,col, length,
            direction, sizeGrid); // Place the word
        wordIndex[wordToTry] = 1; // Mark word as used

        // Recursively place the next word
        if (place_all_words(words, grid, slots, slot + 1, directions, place, wordIndex, 0, sizeGrid)) {
            return 1;
        }

        // Backtrack if placing the word did not lead to a solution
        clean_grid(grid, row, col, length, direction);
        wordIndex[wordToTry] = 0; // Mark word as unused
    }

    // Try the next word in the dictionary
    return place_all_words(words, grid, slots, slot, directions, place, wordIndex, wordToTry + 1, sizeGrid);
}




int main() {
    int task = -1; // Variable to store task choice
    do {
        // Display menu
        printf("Choose an option:\n"
               "1. Robot Paths\n"
               "2. The Human Pyramid\n"
               "3. Parenthesis Validation\n"
               "4. Queens Battle\n"
               "5. Crossword Generator\n"
               "6. Exit\n");

        if (scanf("%d", &task)) { // Read user input
            switch (task) {
            case 6: {
                printf("Goodbye!\n");
                break; // Exit the loop
            }
            case 1: {
                task1_robot_paths();
                break; // Task 1: Robot paths
            }
            case 2:
                task2_human_pyramid();
                break; // Task 2: Human pyramid
            case 3:
                task3_parenthesis_validator();
                break; // Task 3: Parenthesis validation
            case 4:
                task4_queens_battle();
                break; // Task 4: Queens battle
            case 5:
                task5_crossword_generator();
                break; // Task 5: Crossword generator
            default:
                printf("Please choose a task number from the list.\n");
                break;
            }
        } else {
            scanf("%*s"); // Ignore invalid input
        }
    } while (task != 6);
    return 0;
}

void task1_robot_paths()
{
    int column, row; // Coordinates of the robot
    printf("Please enter the coordinates of the robot (column, row):\n");
    scanf("%d %d", &column, &row); // Input coordinates
    if (column < 0 || row < 0) { // Check for invalid coordinates
        printf("The total number of paths the robot can take to reach home is: %d\n", 0);
    }
    else {
        // Calculate and print the number of paths
        printf("The total number of paths the robot can take to reach home is: %d\n",number_of_paths(column, row));
    }
}

void task2_human_pyramid()
{
    printf("Please enter the weights of the cheerleaders:\n");
    float weights[NUMBER_OF_ROWS_IN_PYRAMID][NUMBER_OF_ROWS_IN_PYRAMID] = {0}; // Initialize weights array
    for (int i = 0; i < NUMBER_OF_ROWS_IN_PYRAMID; i++) { // Input weights row by row
        for (int j = 0; j <= i; j++) {
            scanf("%f", &weights[i][j]); // Input weight of a cheerleader
            if(weights[i][j] < 0 ) {
                printf("Negative weights are not supported.\n");
                return;
            }
        }
    }
    printf("The total weight on each cheerleader is:\n");
    for (int i = 0; i < NUMBER_OF_ROWS_IN_PYRAMID; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%.2f ", update_weight(i, j, weights)); // Print updated weight
        }
        printf("\n"); // New line after each row
    }
}

void task3_parenthesis_validator() {
    printf("Please enter a term for validation:\n");
    getchar();
    if (!validparenthesis('\0')) { // Check if parentheses are valid
        printf("The parentheses are balanced correctly.\n");
    } else {
        printf("The parentheses are not balanced correctly.\n");
    }
}
void task4_queens_battle() {
    char board[SIZE][SIZE] = {0}; // Input board
    char boardSolve[SIZE][SIZE] = {0}; // Solution board
    int N; // Board size
    printf("Please enter the board dimensions:\n");
    scanf("%d", &N); // Input board size
    printf("Please enter a %d*%d puzzle board:\n", N, N);
    for (int i = 0; i < N; i++) { // Input board configuration
        for (int j = 0; j < N; j++) {
            scanf(" %c", &board[i][j]); // Input board cell
            boardSolve[i][j] = '*'; // Initialize solution board
        }
    }
    if (placeAllQueens(boardSolve, board, 0, 0, N)) { // Solve the puzzle
        printf("Solution:\n");
        for (int i = 0; i < N; i++) { // Print the solution board
            for (int j = 0; j < N; j++) {
                printf("%c ", boardSolve[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("This puzzle cannot be solved.\n");
    }
}

void task5_crossword_generator()
{
    int numWords; // Number of words in the dictionary
    int sizeGrid; // Size of the crossword grid
    int slots; // Number of slots in the crossword
    printf("Please enter the dimensions of the crossword grid:\n");
    scanf("%d", &sizeGrid); // Input grid size
    char grid[SIZE][SIZE]; // Initialize crossword grid
    for (int i = 0; i < sizeGrid; i++) {
        for (int j = 0; j < sizeGrid; j++) {
            grid[i][j] = '#'; // Initialize grid cells with '#'
        }
    }
    printf("Please enter the number of slots in the crossword:\n");
    scanf("%d", &slots); // Input number of slots
    int place[slots][3]; // Slot details (row, column, length)
    char directions[slots]; // Slot directions (H/V)
    printf("Please enter the details for each slot (Row, Column, Length, Direction):\n");
    for (int i = 0; i < slots; i++) {
        scanf("%d %d %d %c", &place[i][0], &place[i][1], &place[i][2], &directions[i]); // Input slot details
    }

    printf("Please enter the number of words in the dictionary:\n");
    scanf("%d", &numWords); // Input number of words
    while (numWords < slots) { // Ensure enough words for the slots
        printf("The dictionary must contain at least %d words. Please enter a valid dictionary size:\n", slots);
        scanf("%d", &numWords); // Input valid dictionary size
    }
    char words[numWords][15]; // Dictionary of words
    printf("Please enter the words for the dictionary:\n");
    for (int i = 0; i < numWords; i++) {
        scanf("%s", words[i]); // Input words
    }
    int wordIndex[SIZE] = {0}; // Array to track placed words
    if (!place_all_words(words, grid, slots, 0, directions, place, wordIndex, 0, sizeGrid)) {
        printf("This crossword cannot be solved.\n"); // No solution possible
    } else {
        for (int i = 0; i < sizeGrid; i++) { // Print the crossword grid
            for (int j = 0; j < sizeGrid; j++) {
                printf("| %c ", grid[i][j]);
            }
            printf("|\n");
        }
    }
}
